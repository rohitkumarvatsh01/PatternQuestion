package Patterns;
import java.util.Scanner;
public class Pattern12 {
	public static void pattern() {
		for(char i='A'; i<='E'; i++) {
			for(char j='A'; j<=i; j++) {
				System.out.print(i);
			}
			System.out.println();
		}
	}
	
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		
		pattern();
	}
}